import os
import chromadb
from llama_cpp import Llama
from sentence_transformers import SentenceTransformer

class SalusEngine:
    """
    Local-first medical triage RAG backend tailored for 8GB RAM.
    Uses Phi-3-mini (GGUF) and ChromaDB with SentenceTransformers.
    """
    def __init__(self, model_path='models/Phi-3-mini-4k-instruct-q4.gguf', db_path='data/vector_db'):
        print("[Salus Engine] Initializing local-first backend...")
        
        # 1. Initialize SentenceTransformer ('all-MiniLM-L6-v2')
        # This model is small (~80MB) and efficient for 8GB RAM targets.
        self.embed_model = SentenceTransformer('all-MiniLM-L6-v2')
        
        # 2. Initialize ChromaDB (Persistent)
        self.db_client = chromadb.PersistentClient(path=db_path)
        self.collection = self.db_client.get_or_create_collection(name="medical_guidelines")
        
        # Seed the DB if it's empty
        if self.collection.count() == 0:
            self._seed_mock_guidelines()

        # 3. Initialize Llama model (Phi-3-mini-q4)
        # n_ctx=2048 and n_threads=4 to manage memory and CPU overhead.
        if not os.path.exists(model_path):
            print(f"[Salus Engine] WARNING: Model file not found at {model_path}. Please ensure it is present for triage.")
            self.llm = None
        else:
            self.llm = Llama(
                model_path=model_path,
                n_ctx=2048,
                n_threads=4,
                verbose=False # Set to True for debugging llama_cpp logs
            )
            print("[Salus Engine] Phi-3 model loaded successfully.")

    def _seed_mock_guidelines(self):
        """Inserts seed clinical guidelines into ChromaDB if empty."""
        print("[Salus Engine] Seeding initial clinical guidelines...")
        mock_guidelines = [
            {"id": "G1", "text": "Chest Pain Assessment: Immediate referral to emergency care if pain is described as crushing, pressure-like, or radiates to the left arm or jaw. Check for shortness of breath."},
            {"id": "G2", "text": "Fever Management: For adult temperatures above 39°C (102.2°F), advise hydration and paracetamol. Seek medical attention if fever lasts >3 days or is accompanied by stiff neck."},
            {"id": "G3", "text": "Respiratory Distress: Monitor oxygen saturation. If vitals show SpO2 below 92% or respiratory rate above 24 bpm, urgent clinical intervention is required."},
            {"id": "G4", "text": "Minor Wound Care: Clean with sterile water/saline. Apply topical antiseptic. Refer if deep, excessively bleeding, or showing signs of infection (pus, warmth)."},
            {"id": "G5", "text": "Dehydration: Symptoms include dry mouth, dizziness, and low urine output. Recommend oral rehydration salts (ORS). Refer if patient cannot keep fluids down."}
        ]
        
        texts = [item["text"] for item in mock_guidelines]
        ids = [item["id"] for item in mock_guidelines]
        
        # Generate embeddings using our local model
        embeddings = self.embed_model.encode(texts).tolist()
        
        self.collection.add(
            documents=texts,
            ids=ids,
            embeddings=embeddings
        )
        print(f"[Salus Engine] Seeded {len(mock_guidelines)} guidelines into local vector DB.")

    def triage_patient(self, vitals, symptoms):
        """
        Queries the local DB for context and generates a triage response using the LLM.
        """
        if not self.llm:
            return "Error: LLM engine not initialized. Check model path."

        print(f"[Salus Engine] Processing triage for symptoms: {symptoms[:50]}...")

        # 1. Query Local DB for Clinical Context
        query_embedding = self.embed_model.encode([symptoms]).tolist()
        search_results = self.collection.query(
            query_embeddings=query_embedding,
            n_results=2
        )
        
        clinical_context = "\n".join(search_results['documents'][0])
        
        # 2. Inject Context into Phi-3 Chat Template
        # Phi-3 typically uses <|system|>, <|user|>, <|assistant|> delimiters.
        prompt = f"""<|system|>
You are a medical triage assistant. Use the Clinical Guidelines below to provide a safe and concise assessment.
Clinical Guidelines:
{clinical_context}<|end|>
<|user|>
PATIENT VITALS: {vitals}
PATIENT SYMPTOMS: {symptoms}

Evaluate the urgency (Low, Medium, High, Emergency) and suggest the next best step.<|end|>
<|assistant|>"""

        # 3. Generate Response
        output = self.llm(
            prompt,
            max_tokens=256,
            stop=["<|end|>", "User:", "Assistant:"],
            echo=False
        )
        
        return output['choices'][0]['text'].strip()

if __name__ == "__main__":
    # Internal test run
    engine = SalusEngine()
    
    # Example scenario
    test_vitals = "Temp: 39.5C, HR: 110 bpm, SpO2: 95%"
    test_symptoms = "Persistent high fever for 4 days, stiff neck, and severe headache."
    
    print("\n--- TEST TRIAGE RUN ---")
    if engine.llm:
        assessment = engine.triage_patient(test_vitals, test_symptoms)
        print(f"ASSESSMENT:\n{assessment}")
    else:
        print("Test skipped: LLM not loaded.")