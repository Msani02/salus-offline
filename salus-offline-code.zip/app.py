import customtkinter as ctk
import threading
from engine import SalusEngine

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# Localization Dictionary for English, Hausa, Yoruba, and Igbo
LOCALIZATION = {
    "English": {
        "title": "Salus - Local Medical Triage RAG", "sidebar_title": "PATIENT VITALS",
        "age": "Age (years)", "temp": "Temperature (°C)", "bp": "Blood Pressure (mmHg)", "hr": "Heart Rate (bpm)",
        "symptoms_title": "Patient Symptoms / Complaints (Press Ctrl+Enter to Triage)",
        "ready": "Backend Ready | Press Ctrl+Enter inside symptoms to run",
        "processing": "Processing locally on CPU...", "waiting": "Waiting for input...",
        "complete": "Assessment Complete | Press Ctrl+Enter to run again", "fill_err": "Please fill in vitals and symptoms first"
    },
    "Hausa": {
        "title": "Salus - Tsarin Triage Na Lafiya", "sidebar_title": "ALAMOMIN MARAS LAFIYA",
        "age": "Shekaru (years)", "temp": "Zafin Jiki (°C)", "bp": "Hawan Jini (mmHg)", "hr": "Bugun Zuciya (bpm)",
        "symptoms_title": "Alamomin Rashin Lafiya / Korafi (Danna Ctrl+Enter don Triage)",
        "ready": "Backend Ya Shirya | Danna Ctrl+Enter a cikin akwatin alamomi don farawa",
        "processing": "Ana sarrafawa a cikin kwamfuta (CPU)...", "waiting": "Ana jiran bayanai...",
        "complete": "An Kammala Bincike | Danna Ctrl+Enter don sake gudanarwa", "fill_err": "Da fatan za a cika alamomin jiki da korafi da farko"
    },
    "Yoruba": {
        "title": "Salus - Eto Triage Ilera Agbegbe", "sidebar_title": "ÀWỌN ÀMÌ ARA ALÁÌSÀN",
        "age": "Ọjọ́ orí (years)", "temp": "Ìgbóná Ara (°C)", "bp": "Ìfúnpá Jìgí (mmHg)", "hr": "Ìlù Sọ́kọ̀ Ọkàn (bpm)",
        "symptoms_title": "Àwọn Àmì Àìsàn / Àwọn Ìfarahàn (Tẹ Ctrl+Enter fun Triage)",
        "ready": "Eto ti Wa Nílẹ̀ | Tẹ Ctrl+Enter ninu apoti fun ayẹwo",
        "processing": "Alaye n lọ lori kọmputa (CPU)...", "waiting": "A n duro de alaye...",
        "complete": "Ayẹwo Ti Pari | Tẹ Ctrl+Enter lati tun bẹrẹ", "fill_err": "Jọwọ fọwọsi awọn ami ara ati awọn aarun rẹ kọkọ"
    },
    "Igbo": {
        "title": "Salus - Usoro Triage Ahụike Obodo", "sidebar_title": "IHE IRU AHỤ NDỊ GBANWEE",
        "age": "Afọ (years)", "temp": "Okpomọkụ Ahụ (°C)", "bp": "Ihe Nlele Ọbara (mmHg)", "hr": "Mmetụta Obi (bpm)",
        "symptoms_title": "Ihe Mgbaàmà / Mkpesa Ndị Ọrịa (Pịa Ctrl+Enter ka Imee Triage)",
        "ready": "Sistemụ Adịla Njikere | Pịa Ctrl+Enter n'ime igbe maka triage",
        "processing": "Ọ na-arụ ọrụ na kọmputa (CPU)...", "waiting": "Na-eche ntinye alaye...",
        "complete": "Nyocha Agwụla | Pịa Ctrl+Enter ka ịmalite ọzọ", "fill_err": "Biko dejupụta ihe mgbaàmà ahụ tupu ịmalite"
    }
}

class SalusApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.current_lang = "English"
        
        self.title(LOCALIZATION[self.current_lang]["title"])
        self.geometry("1000x680")
        
        self.grid_columnconfigure(0, weight=1, minsize=300)
        self.grid_columnconfigure(1, weight=3)
        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=0, minsize=250)

        self.engine = SalusEngine()
        self.is_processing = False

        self._init_sidebar()
        self._init_main_pane()
        self._init_output_pane()

    def _init_sidebar(self):
        self.sidebar_frame = ctk.CTkFrame(self, corner_radius=0)
        self.sidebar_frame.grid(row=0, column=0, rowspan=2, sticky="nsew", padx=1, pady=1)
        
        self.sidebar_title = ctk.CTkLabel(self.sidebar_frame, text=LOCALIZATION[self.current_lang]["sidebar_title"], font=ctk.CTkFont(size=20, weight="bold"))
        self.sidebar_title.pack(padx=20, pady=(20, 10))

        # Language Selector Dropdown
        self.lang_lbl = ctk.CTkLabel(self.sidebar_frame, text="Select Language / Zabi Harshe", font=ctk.CTkFont(size=12, weight="bold"))
        self.lang_lbl.pack(padx=25, anchor="w")
        self.lang_menu = ctk.CTkOptionMenu(self.sidebar_frame, values=["English", "Hausa", "Yoruba", "Igbo"], command=self._change_language)
        self.lang_menu.pack(fill="x", padx=25, pady=(5, 15))

        self.vital_entries = {}
        self.vitals_specs = [("Age", "age"), ("Temperature", "temp"), ("Blood Pressure", "bp"), ("Heart Rate", "hr")]
        self.vital_labels = {}
        
        for name, key in self.vitals_specs:
            lbl = ctk.CTkLabel(self.sidebar_frame, text=LOCALIZATION[self.current_lang][key], anchor="w")
            lbl.pack(fill="x", padx=25, pady=(5, 0))
            self.vital_labels[key] = lbl
            
            entry = ctk.CTkEntry(self.sidebar_frame, placeholder_text="...")
            entry.pack(fill="x", padx=25, pady=(2, 8))
            self.vital_entries[name] = entry

    def _init_main_pane(self):
        self.main_container = ctk.CTkFrame(self, fg_color="transparent")
        self.main_container.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        
        self.symptoms_lbl = ctk.CTkLabel(self.main_container, text=LOCALIZATION[self.current_lang]["symptoms_title"], font=ctk.CTkFont(size=15, weight="bold"))
        self.symptoms_lbl.pack(anchor="w", pady=(0, 10))
        
        self.symptoms_box = ctk.CTkTextbox(self.main_container, height=250, border_width=1)
        self.symptoms_box.pack(fill="both", expand=True, pady=10)
        self.symptoms_box.bind("<Control-Return>", lambda event: self.execute_triage())
        
        self.control_frame = ctk.CTkFrame(self.main_container, fg_color="transparent")
        self.control_frame.pack(fill="x", pady=5)
        
        self.status_lbl = ctk.CTkLabel(self.control_frame, text=f"● {LOCALIZATION[self.current_lang]['ready']}", text_color="#10b981")
        self.status_lbl.pack(anchor="w")

    def _init_output_pane(self):
        self.output_frame = ctk.CTkFrame(self, corner_radius=10, border_width=1, border_color="#1f538d")
        self.output_frame.grid(row=1, column=1, sticky="nsew", padx=20, pady=(0, 20))
        
        self.output_lbl = ctk.CTkLabel(self.output_frame, text="AI TRIAGE RESULT & GUIDELINES", font=ctk.CTkFont(size=14, weight="bold"), text_color="#3b82f6")
        self.output_lbl.pack(anchor="w", padx=15, pady=(10, 5))
        
        self.output_area = ctk.CTkTextbox(self.output_frame, font=ctk.CTkFont(family="Consolas", size=13))
        self.output_area.pack(fill="both", expand=True, padx=15, pady=(0, 15))
        self._update_output_content(LOCALIZATION[self.current_lang]["waiting"])

    def _change_language(self, chosen_lang):
        self.current_lang = chosen_lang
        self.title(LOCALIZATION[self.current_lang]["title"])
        self.sidebar_title.configure(text=LOCALIZATION[self.current_lang]["sidebar_title"])
        self.symptoms_lbl.configure(text=LOCALIZATION[self.current_lang]["symptoms_title"])
        self._set_status(LOCALIZATION[self.current_lang]["ready"], "#10b981")
        
        for _, key in self.vitals_specs:
            self.vital_labels[key].configure(text=LOCALIZATION[self.current_lang][key])

    def _update_output_content(self, text):
        self.output_area.configure(state="normal")
        self.output_area.delete("0.0", "end")
        self.output_area.insert("0.0", text)
        self.output_area.configure(state="disabled")

    def execute_triage(self):
        if self.is_processing: return
        vitals_data = {name: entry.get().strip() for name, entry in self.vital_entries.items()}
        symptoms = self.symptoms_box.get("0.0", "end").strip()
        
        if not symptoms or not any(vitals_data.values()):
            self._set_status(LOCALIZATION[self.current_lang]["fill_err"], "#ef4444")
            return

        vitals_summary = ", ".join([f"{k}: {v}" for k, v in vitals_data.items() if v])
        self.is_processing = True
        self._set_status(LOCALIZATION[self.current_lang]["processing"], "#3b82f6")
        self._update_output_content("RAG Pipeline Active...")

        threading.Thread(target=self._run_threaded_triage, args=(vitals_summary, symptoms), daemon=True).start()

    def _run_threaded_triage(self, vitals, symptoms):
        try:
            # Pass chosen language down to system prompt context rules
            lang_instruction = f" Respond completely in the {self.current_lang} language." if self.current_lang != "English" else ""
            modified_symptoms = symptoms + lang_instruction
            assessment = self.engine.triage_patient(vitals, modified_symptoms)
            self.after(0, lambda: self._on_triage_complete(assessment))
        except Exception as e:
            self.after(0, lambda: self._on_triage_complete(f"Error: {str(e)}"))

    def _on_triage_complete(self, result):
        self._update_output_content(result)
        self.is_processing = False
        self._set_status(LOCALIZATION[self.current_lang]["complete"], "#10b981")

    def _set_status(self, text, color="gray"):
        self.status_lbl.configure(text=f"● {text}", text_color=color)

if __name__ == "__main__":
    app = SalusApp()
    app.mainloop()